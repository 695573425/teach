#include <iostream>
#include <stack>


#define max_siez 20

using namespace std;



struct node{
    node *lc;
    node *rc;
    char ch;
};
typedef node *Btree;


void recursion_createtree(Btree* A, Btree* B, Btree c, int i, int j, int len) //已知二叉树的前序序列和中序序列，建立二叉树的递归算法
{
    int m;
    m=0;
    if(len<=0)
        return;
    while(B[m]!= c)
        m++;
    c = A[i];
    recursion_createtree(A, B, c->lc, i+1, j, m-j);
    recursion_createtree(A, B, c->rc, i+(m-j)+1, m+1, len-1-(m-j));

}

void nonrecursion_createtree(Btree* A,Btree* B,int len)  //已知二叉树的前序序列和中序序列，建立二叉树的非递归算法
{
    stack<int> s;
    int i,j,k;
    for(i=0;i<len;i++)
    {
        j=0;
        while(B[j]->ch != A[i]->ch)
            j++;
        if(s.empty())
            s.push(j);
        else
        {
            if(j<s.top())
            {
                B[s.top()]->lc = B[j];
                s.push(j);
            }
            else
            {
                while(j>s.top() && !s.empty())
                {
                    k = s.top();
                    s.pop();
                }
                B[k]->rc = B[j];
                s.push(j);
            }
        }

    }

}


void recur_preorder(Btree c)          //前序遍历递归算法
{
    if (c!=NULL)
    {
        cout<<c->ch;
        recur_preorder(c->lc);
        recur_preorder(c->rc);
    }
}

void non_preorder(Btree c)            //前序遍历非递归算法
{
    Btree temp;
    temp = c;
    stack<Btree> s;
    while(temp!=NULL || !s.empty())
    {
        while(temp!=NULL)
        {
            cout<<temp->ch;
            s.push(temp);
            temp = temp->lc;
        }
        if(!s.empty())
        {
            temp = s.top();
            s.pop();
            temp = temp->rc;
        }
    }
}

void recur_inorder(Btree c)         //中序遍历递归算法
{
    if (c!=NULL)
    {
        recur_preorder(c->lc);
        cout<<c->ch;
        recur_preorder(c->rc);
    }
}

void non_inorder(Btree c)          //中序遍历非递归算法
{
    Btree temp;
    temp = c;
    stack<Btree> s;
    while(temp!=NULL || !s.empty())
    {
        while(temp!=NULL)
        {
            s.push(temp);
            temp = temp->lc;
        }
        if(!s.empty())
        {
            temp = s.top();
            s.pop();
            cout<<temp->ch;
            temp = temp->rc;
        }
    }
}

void recur_postorder(Btree c)         //后序遍历递归算法
{
    if (c!=NULL)
    {
        recur_preorder(c->lc);
        recur_preorder(c->rc);
        cout<<c->ch;
    }
}

void non_postorder(Btree c)          //后序遍历非递归算法
{
    Btree temp,pr;
    temp = c;
    stack<Btree> s;
    while(temp!=NULL || !s.empty())
    {
        while(temp!=NULL)
        {
            s.push(temp);
            pr = temp->rc;
            temp = temp->lc;
            if(temp==NULL)
                temp = pr;
        }
        temp = s.top();
        s.pop();
        cout<<temp->ch;
        if(!s.empty() && s.top()->lc == temp)
            temp = s.top()->rc;
        else
            temp = NULL;
    }
}

void leverOrder(Btree c)           //层序遍历
{
    Btree Q[max_siez];
    Btree q;
    int fron,rear;
    fron = rear =0;
    if(c==NULL)
        return;
    Q[++rear] = c;
    while(fron!=rear)
    {
        q = Q[++fron];
        cout<<q->ch;
        if(q->lc!=NULL)
            Q[++rear] = q->lc;
        if(q->rc!=NULL)
            Q[++rear] = q->rc;
    }

}




int main()
{

    return 0;
}

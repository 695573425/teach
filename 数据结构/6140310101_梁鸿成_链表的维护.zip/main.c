#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct goods{
    char name[20];
    char brand[20];
    float unitprice;
    int  quantity;
    struct goods *next;
};
typedef struct goods *List;
typedef struct goods *position;

position found(char* a,char* b,float x,int y)
{
    position q;
    q = malloc(52);
    strcpy(q->name,a);
    strcpy(q->brand,b);
    q->unitprice = x;
    q->quantity = y;
    q->next = NULL;
    return q;
}

void goods_in(List L, position p)
{
    List q,temp;
    q = L;
    if (q==NULL)
    {
        q->next = p;
        return;
    }
    else
    {
        while(p->unitprice >= q->next->unitprice)
        {
            q = q->next;
            if (strcmp(p->name,q->name)==0&&strcmp(p->brand,q->brand))
                q->quantity += p->quantity;
            else if (q->next == NULL)
            {
                q->next = p;
                return;
            }
        }
        temp = q->next;
        q->next = p;
        p->next = temp;
        return;
    }
}

void goods_out(List L, char* a, char*b, int x)
{
    List q,temp;
    q = L;
    while(strcmp(q->next->name,a)!=0 || strcmp(q->next->brand,b)!=0)
    {
        q = q->next;
        if (q->next == NULL)
        {
            printf("�ֿ�û�и���Ʒ\n");
            return;
        }
    }
    if(q->next->quantity < x)
    {
        printf("��治��\n");
    }
    else if(q->next->quantity == x)
    {
        printf("����Ʒ���޴��\n");
        if(q->next->next ==NULL)
        {
            free(q->next);
            q->next = NULL;
        }
        else
        {
            temp = q->next;
            free(temp);
            q->next = q->next->next;

        }
    }
    else
    {
        q->next->quantity -= x;
        printf("����Ʒ���ʣ�ࣺ%d\n",q->next->quantity);
    }

}

position index(List L, char* a, char* b)
{
    List q;
    q = L;
    while(strcmp(q->next->name,a)!=0 || strcmp(q->next->brand,b)!=0)
    {
        q = q->next;
        if(q->next ==NULL)
        {
            printf("�ֿ�û�и���Ʒ");
            return NULL;
        }
    }
    return q->next;
}

void update(List L, char* a, char* b, position p)
{
    position q;
    q = index(L,a,b);
    if (q==NULL)
    {
        printf("�ֿ�û�и���Ʒ\n");
    }
    else
    {
        strcpy(q->name,p->name);
        strcpy(q->brand,p->brand);
        q->unitprice = p->unitprice;
        q->quantity = p->quantity;
        free(p);
    }
}

List start()
{
    char str[50];
    char str1[10];
    List L,p;
    FILE *f;
    int len1,len2,i,j;
    len1 = j =0;
    len2 = -1;
    L = malloc(4);
    p = L;
    if((f=fopen("test.txt","r")) == NULL)
    {
        printf("fail to read");
        return NULL;
    }
    while(fgets(str,50,f)!=NULL)
    {
        p->next = malloc(52);
        p = p->next;
        for(i=0;i<strlen(str);i++)
        {
            len2++;
            if(str[i]==' ')
            {
                switch(j){
                    case 0 :{
                        strncpy(p->name,str+len1,len2);
                        len1 = i+1;
                        len2 = -1;
                        j++;
                    }
                    case 1 :{
                        strncpy(p->brand,str+len1,len2);
                        len1 = i+1;
                        len2 = -1;
                        j++;
                    }
                    case 2 :{
                        strncpy(str1,str+len1,len2);
                        p->unitprice = (float)atof(str1);
                        len1 = i+1;
                        len2 = -1;
                        j++;
                    }
                    case 3 :{
                        strncpy(str1,str+len1,len2);
                        p->unitprice = atoi(str1);
                        len1 = 0;
                        len2 = -1;
                        j=0;
                    }
                }

            }
        }
    }
    p->next =NULL;
    fclose(f);
    return L;
}

void end(List L)
{
    FILE *f;
    List p;
    char str[50];
    char str1[20];
    p = L;
    if((f=fopen("test1.txt","w")) == NULL)
    {
        printf("fail to open");
        return NULL;
    }
    while(p->next != NULL)
    {
        strcpy(str,p->next->name);
        strcat(str," ");
        strcat(str,p->next->brand);
        strcat(str," ");
        sprintf(str1,"%f",p->next->unitprice);
        strcat(str,str1);
        strcat(str," ");
        strcat(str,itoa(p->next->quantity,str1,10));
        strcat(str,str1);
        strcat(str," ");
        fputs(str,f);
        p = p->next;
    }
    fclose(f);
}
int main()
{


    return 0;
}

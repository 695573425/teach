#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max_size 100
typedef struct{
    int data;
    int next;
}stack;

typedef stack s_share[max_size]; //��ջ����ͬһ����ռ䣬����ͷ�����ռ䴢��ջ��������ĩ�������ջ����ջ��Ԫ��nextΪ-1��

int pop1(int i,s_share S)  //�ѿռ�s_share�е�i��ջ��ջ
{
    int x,temp;
    temp = S[i].next;
    x = S[temp].data;
    S[i].next = S[temp].next;
    S[temp].next = S[max_size-1].next;
    S[max_size-1].next = temp;
    return x;
}


struct node{
    char data[4];
    struct node* next;
};
typedef struct node* head;
typedef struct node* str;

index(char s[],head H)
{
    char *S;
    str temp;
    temp = H;
    while(temp->next != NULL)
    {
        strcat(S,temp->next->data);
        temp = temp->next;
    }
    int len1,len2;
    int i,j;
    len1 = strlen(S);
    len2 = strlen(s);
    i = j = 0;
    while((i<len1) && (j<len2))
    {
        if(S[i] ==s[j])
        {
            ++i;
            ++j;
        }
        else
        {
            i = i-j+1;
            j = 0;
        }
    }
    if(j==len2)
        return i-len2;
    else
        return -1;
}


int main()
{


    return 0;
}

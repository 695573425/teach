#include <iostream>
#include <stack>
#define max_size 100
using namespace std;

typedef struct node{
    int adjvex;
    int cost;
    node* next;
}EdgeNode;


typedef struct{
    int data;
    node* firstedge;
}VertexNode;

typedef struct {
    VertexNode vexlist[max_size];
    int n,e;
}AdjGraph;

bool visited[max_size];
int dfn[max_size];
void DFS(AdjGraph G,int i)       //������ȵݹ��㷨
{
     EdgeNode *p;
     int _count =1;
     cout<<G.vexlist[i].data<<" ";
     visited[i]=true;
     dfn[i]=_count++;
     p=G.vexlist[i].firstedge;
     while(p!=NULL) {
            if(visited[p->adjvex]==false)
            DFS(G, p->adjvex);
            p=p->next;
     }
}

void DFS1(AdjGraph G,int i)     //������ȷǵݹ��㷨
{
     stack<int> s;                   //������ջs
     EdgeNode *p;
     int _count =1;
     int j;
     cout<<G.vexlist[i].data<<" ";
     visited[i] = true;
     s.push(i);
     dfn[i] = _count++;
     while(!s.empty())                               //�ж�ջ����ָ��㣬���η����ڽӵ㣬��δ���ʹ������ڽӵ���ʲ�ѹջ
     {                                               //���������ڽӵ���ѷ��ʣ���ջ����ջ��ֱ��ջ��Ϊֹ
         j=s.top();
         p=G.vexlist[j].firstedge;
         while(p!=NULL)
         {
             if(visited[p->adjvex]==false)
                break;
             else
                p=p->next;
         }
         if(p!=NULL)
         {
             cout<<G.vexlist[p->adjvex].data<<" ";
             visited[p->adjvex]=true;
             s.push(p->adjvex);
         }
         else
            s.pop();
     }

}


void DFSTraverseP(AdjGraph G)
{
    int i;
    for(i=0;i<G.n;i++)
        visited[i] = false;
    for(i=0;i<G.n;i++)
        if(visited[i]==false)
        DFS(G,i);

}

void DFS1TraverseP(AdjGraph G)
{
    int i;
    for(i=0;i<G.n;i++)
        visited[i] = false;
    for(i=0;i<G.n;i++)
        if(visited[i]==false)
        DFS1(G,i);

}
void BFS(AdjGraph G, int k)      //������ȷǵݹ��㷨
{
    int i;
    EdgeNode *p;
    int Q[max_size];
    int fron,rear;
    fron=rear=0;
    cout << G.vexlist[k].data<<" ";
    visited[k] = true;
    Q[++rear] = k;
    while(fron!=rear){
            i = Q[++fron];
            p = G.vexlist[i].firstedge;
            while(p!=NULL)
            {
                if(visited[p->adjvex]==false)
                {
                    cout<<G.vexlist[p->adjvex].data<<" ";
                    visited[p->adjvex] = true;
                    Q[++rear] = p->adjvex;
                }
                p = p->next;
            }
    }
}


void BFSTraverseP(AdjGraph G)
{
    int i;
    for(i=0;i<G.n;i++)
        visited[i] = false;
    for(i=0;i<G.n;i++)
        if(visited[i]==false)
        BFS(G,i);

}
EdgeNode* makeedge(int i)
{
    EdgeNode *p;
    p = new node;
    p->adjvex = i;
    p->next = NULL;
    return p;
}
int main()
{
    EdgeNode *p;
    AdjGraph G;
    G.n = 10;
    G.e = 0;
    int i;
    for(i=0; i<10;i++)
        G.vexlist[i].data = i;
    p = G.vexlist[0].firstedge = makeedge(1);
    p = p->next = makeedge(2);
    p = p->next = makeedge(3);
    p = p->next = NULL;
    p = G.vexlist[1].firstedge = makeedge(0);
    p = p->next = makeedge(2);
    p = p->next = makeedge(4);
    p = p->next = NULL;
    p = G.vexlist[2].firstedge = makeedge(0);
    p = p->next = makeedge(1);
    p = p->next = makeedge(5);
    p = p->next = NULL;
    p = G.vexlist[3].firstedge = makeedge(5);
    p = p->next = NULL;
    p = G.vexlist[4].firstedge = makeedge(6);
    p = p->next = makeedge(9);
    p = p->next = NULL;
    p = G.vexlist[5].firstedge = makeedge(7);
    p = p->next = makeedge(3);
    p = p->next = NULL;
    p = G.vexlist[6].firstedge = makeedge(4);
    p = p->next = makeedge(9);
    p = p->next = NULL;
    p = G.vexlist[7].firstedge = makeedge(8);
    p = p->next = NULL;
    p = G.vexlist[8].firstedge = NULL;
    p = G.vexlist[9].firstedge = makeedge(4);
    p = p->next = makeedge(6);
    p = p->next = NULL;

    for(i=0;i<10;i++)
    {
        EdgeNode *p;
        cout<<G.vexlist[i].data<<" ";
        p=G.vexlist[i].firstedge;
        while(p!=NULL)
        {
            cout<<p->adjvex<<" ";
            p = p->next;
        }
        cout<<endl;
    }

    cout<<"������ȵݹ��㷨��  ";
    DFSTraverseP(G);
    cout<<endl;
    cout<<"������ȷǵݹ��㷨��";
    DFS1TraverseP(G);
    cout<<endl;
    cout<<"������ȷǵݹ��㷨��";
    BFSTraverseP(G);
    cout<<endl;

    return 0;
}

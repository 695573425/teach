#include <iostream>
#define max_size 20
using namespace std;

struct Edge{
    int bgn,End,weight;
};

int Find(int father[],int i)
{
    int j=i;
    while(father[j]>=0)
        j=father[j];
    return j;
}

void Sort(Edge edges[],int e)
{
    Edge temp;
    for(int i=0; i<e-1; i++)
    {
        for(int j=0; j<e-1; j++)
        {
            if(edges[j].weight>edges[j+1].weight)
            {
                temp = edges[j];
                edges[j] = edges[j+1];
                edges[j+1] = temp;
            }
        }
    }

}

void Kruskal(Edge edges[],int label[],int e)
{
    int bnf,edf,i;
    int father[e];
    for(i=0; i<e; i++)
    {
        label[i] = -1;
        father[i]= -1;
    }
    for(i=0; i<e; i++)
    {
        bnf = Find(father,edges[i].bgn);
        edf = Find(father,edges[i].End);
        if(bnf!=edf)
        {
            father[bnf] = edf;
            label[i]++;
        }
    }
}

Edge makeedge(int bgn, int End, int weight)
{
    Edge e;
    e.bgn = bgn;
    e.End = End;
    e.weight = weight;
    return e;
}
int main()
{
    int e=0;
    int i;
    Edge edges[max_size];
    edges[e++] = makeedge(0,1,2);
    edges[e++] = makeedge(0,2,3);
    edges[e++] = makeedge(1,3,2);
    edges[e++] = makeedge(2,3,1);
    edges[e++] = makeedge(3,4,2);
    edges[e++] = makeedge(3,5,4);
    edges[e++] = makeedge(4,5,1);
    edges[e++] = makeedge(4,6,2);
    edges[e++] = makeedge(5,6,2);
    edges[e++] = makeedge(5,7,1);
    edges[e++] = makeedge(6,7,3);
    Sort(edges,e);
    cout<<"ͼ���ߵ�ͷ��β��Ȩֵ��"<<endl;
    for(i=0; i<e; i++)
        cout<<edges[i].bgn<<" "<<edges[i].End<<" "<<edges[i].weight<<endl;
    int label[e];
    Sort(edges,e);
    Kruskal(edges,label,e);
    cout<<"Kruskal�㷨����С��������"<<endl;
    for(i=0; i<e; i++)
    {
        if(label[i]>=0)
            cout<<edges[i].bgn<<" "<<edges[i].End<<" "<<edges[i].weight<<endl;
    }

    return 0;
}

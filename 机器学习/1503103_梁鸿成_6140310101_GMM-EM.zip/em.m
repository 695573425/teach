%em�㷨
%data:�����ļ�   k��������
function [pw,mu,sigma] = em(data,k)
   
    data = load(data);
    X = data(:,2:end);
    X = X';
    [dim,N] = size(X);
    %��ʼ������
    [pw,mu,sigma] = init_param(X',k);
 
    P = zeros(N,k);
    ite = 0;
    sigma_prev = sigma;
    while true
        %E - ����
        ite = ite +1;
        for i = 1:k
            P(:,i) = pw(i) * gauss(X,mu(:,i),sigma(:,:,i));
        end
        p_sum = sum(P,2);
        for j = 1:N
            P(j,:) = P(j,:)/p_sum(j);
        end
        
        %M - ����
        beta = sum(P);
        for i = 1:k
            pw(i) = beta(i)/N;
            mu(:,i) = X*P(:,i)/beta(i);
            tmp = X - repmat(mu(:,i),1,N);
            sigma(:,:,i) = (repmat(P(:,i)',dim,1) .* tmp*tmp')/beta(i);
        end
        
       %�����ж�
        if sum(sum(sum(abs(sigma-sigma_prev)))) < 1e-4
            break;
        end
        sigma_prev = sigma;
    end
    ite
end

%��˹�ֲ�����������X���ھ�ֵΪmu,����Ϊsigma�ĸ�˹�ֲ�����
function p = gauss(x, mu, sigma)  
    [dim,N]=size(x);  
    p=zeros(1,N);
    for i=1:N  
     p(i)= 1/(2*pi*abs(det(sigma)))^...
         (length(mu)/2)*exp(-0.5*(x(:,i)-mu)'/...
         sigma*(x(:,i)-mu));
    end
end

%��ʼ������
function [pw,mu,sigma] = init_param(X,k)
    [N,dim] = size(X);
    Rn_index = randperm(N);
    mu = X(Rn_index(1:k),:);
    pw = zeros(1,k);
    sigma = zeros(dim,dim,k);
    distmat = repmat(sum(X.*X, 2), 1, k) + ...
        repmat(sum(mu .* mu,2)', N, 1) - ...
        2 * X * mu';
    [~, labels] = min(distmat, [], 2);
    
    for i = 1:k
        Xi = X(labels == i, :);
        pw(i) = size(Xi,1)/N;
        sigma(:, :, i) = cov(Xi);
    end
    mu = mu';
    
end


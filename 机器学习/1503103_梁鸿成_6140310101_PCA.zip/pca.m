function [X,newX,Vk,mu,snr] =  pca()
    X = face_data();
    mu = mean(X);
    X_train = X - repmat(mu,size(X,1),1);
    Cov = cov(X);
    [V,D] = eig(Cov);
    D = diag(D);
    [~,order] = sort(D,'descend');
    V = V(:,order);
    D = D(order)';
    
    %���㹱��ֵ���Ƴ���άά��k
    D_sum = sum(D);
    for i = 1:length(D)
        rate = sum(D(1:i))/D_sum;
        if rate>0.99
            k = i;
            break;
        end
    end
    
    %�ع�
    Vk = V(:, 1:k);
    Z = X_train * Vk;
    newX = Z * Vk';
    newX = newX + repmat(mu,size(newX,1),1);
    
    %���������
    ps = sum(sum((X - mean(mean(X))).^2));
    pn = sum(sum((X-newX).^2));
    snr = 10*log10(ps/pn);
end

%�˹�������ά����
function X = test1()
    a = [1,1,1];
    b = [1,-1,0];
    a_coe = rand(30,1)*100;
    b_coe = rand(30,1)*100;
    X = a_coe * a + b_coe * b;
    X = X + wgn(30,3,10);   
end

%��ȡ��������
function X = face_data()
    path = 'C:\Users\123\Desktop\faces\s';
    X = zeros(100,112*92);
    for i = 1 : 20
        for j = 1: 5
            img = imread(strcat(path,int2str(i),...
                '\',int2str(j),'.pgm'));
            img = reshape(img,1,112*92);
            X(i*j,:) = img;
        end
    end            
end
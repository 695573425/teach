package lab1;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class test {

  @Before
  public void setUp() throws Exception {
  }

  lab1 T = new lab1("E:\\workspace\\lab1\\src\\lab1\\test.txt");

  @Test
  public void test1() {
    String result = T.queryBridgeWords("and", "exciting");
    assertEquals("No \"exciting\" in the graph!",result);
  }

  @Test
  public void test2() {
    String result = T.queryBridgeWords("exciting", "synergies");
    assertEquals("No \"exciting\" and \"synergies\" in the graph!",result);
  }

  @Test
  public void test3() {
    String result = T.queryBridgeWords("to", "explore");
    assertEquals("No bridge words from \"to\" to \"explore\"!",result);
  }

  @Test
  public void test4() {
    String result = T.queryBridgeWords("to", "strange");
    assertEquals("The bridge words from \"to\" to \"strange\" is: explore.",result);
  }

  @Test
  public void test5() {
    String result = T.queryBridgeWords("new", "and");
    assertEquals("The bridge words from \"new\" to \"and\" are: life and civilizations.",result);
  }

  @Test
  public void test6() {
    String result = T.queryBridgeWords("����һ", "to");
    assertEquals("No \"����һ\" in the graph!",result);
  }

  @Test
  public void test7() {
    String result = T.queryBridgeWords("����һ", "���ʶ�");
    assertEquals("No \"����һ\" and \"���ʶ�\" in the graph!",result);
  }



}

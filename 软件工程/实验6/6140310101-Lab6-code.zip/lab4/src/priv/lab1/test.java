package priv.lab1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.Test;

public class test {



  @Test
  public void randomwTest1() throws IOException{
    TextGraph T = new TextGraph("E:\\workspace\\lab4\\src\\priv\\lab1\\test1.txt");
    String result = T.randomWalk();
    assertEquals("we can",result);
  }

  @Test
  public void randomwTest2() throws IOException{
    TextGraph T = new TextGraph("E:\\workspace\\lab4\\src\\priv\\lab1\\test2.txt");
    String result = T.randomWalk();
    assertTrue(result.equals("we can do") || result.equals("can do"));
  }

  @Test
  public void randomwTest3() throws IOException{
    TextGraph T = new TextGraph("E:\\workspace\\lab4\\src\\priv\\lab1\\test3.txt");
    String result = T.randomWalk();
    assertTrue(result.equals("we do") || result.equals("we can we can") ||
        result.equals("we can we do") || result.equals("can we do") ||
        result.equals("can we can we"));
  }


}

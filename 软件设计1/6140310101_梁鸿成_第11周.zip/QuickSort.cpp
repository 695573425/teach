#include <iostream>
#include <windows.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

void QuickSort(int a[], int low, int high)    //һ������㷨
{
    if(low >= high)
    {
        return;
    }
    int first = low;
    int last = high;
    int key = a[first];
    while(first < last)
    {
        while(first < last && a[last] >= key)
        {
            --last;
        }

        a[first] = a[last];

        while(first < last && a[first] <= key)
        {
            ++first;
        }

        a[last] = a[first];

    }
    a[first] = key;
    QuickSort(a, low, first-1);
    QuickSort(a, first+1, high);
}


void InsertSort(int a[],int low,int high)     //��������
{
    int i,j;
    for(i=low+1; i<=high; i++)
    {
        j=i;
        while(j>low && a[j]<a[j-1])
        {
            swap(a[j],a[j-1]);j--;
        }
    }
}

int SelectMedian(int a[],int low,int high)
{
    int b[3];
    b[0] = a[low];
    b[1] = a[(high-low)/2];
    b[2] = a[high];
    InsertSort(b,0,2);
    return b[1];
}

void QuickSort1(int a[], int low, int high)    //�Ż������㷨
{
    if(low >= high)
    {
        return;
    }
    if(high-low<10)
    {
        InsertSort(a,low,high);
        return;
    }
    int i,j,k;
    i=j=0;
    int first = low;
    int last = high;
    int key = SelectMedian(a,first,high);
    while(first < last)
    {
        while(first < last && a[last] >= key)
        {
            if(a[last]==key)
                swap(a[last],a[high-j++]);
            --last;
        }

        a[first] = a[last];

        while(first < last && a[first] <= key)
        {
            if(a[first]==key)
                swap(a[first],a[low+i++]);
            ++first;
        }

        a[last] = a[first];

    }
    a[first] = key;
    for(k=0; k<i; k++)
        swap(a[low+k],a[first-k-1]);
    for(k=0; k<j; k++)
        swap(a[high-k],a[first+k+1]);
    QuickSort1(a, low, first-i-1);
    QuickSort1(a, first+j+1, high);
}

void create_array(int a[],int len,int k)       //���ɲ�������
{
    int i,j;
    for(i=0; i<len; i++)
        a[i] = rand()%(len*3);

    switch(k){
    case 1:
        InsertSort(a,0,len-1);
        break;

    case 2:
        InsertSort(a,0,len-1);
        i=0;j=len;
        while(i<j)
            swap(a[i++],a[j--]);
        break;

    default:
        break;
    }
}

void time_test(int a[],int len)         //һ��������Ż�����ʱ��Ч�ʱȽ�
{
    int b[len];
    int n;
    for(n=0;n<len;n++)
        b[n] = a[n];
    LARGE_INTEGER fre = {0};
    LARGE_INTEGER i = {0};
    LARGE_INTEGER j = {0};
    LARGE_INTEGER k = {0};
    QueryPerformanceFrequency(&fre);

    QueryPerformanceCounter(&i);
    QuickSort(a,0,len-1);
    QueryPerformanceCounter(&j);
    QuickSort1(b,0,len-1);
    QueryPerformanceCounter(&k);

    double time1 = ((double)j.QuadPart -(double)i.QuadPart)/(double)fre.QuadPart;
    double time2 = ((double)k.QuadPart -(double)j.QuadPart)/(double)fre.QuadPart;

    cout<<"һ������㷨ʱ��Ч�ʣ� "<<time1*1000<<endl;
    cout<<"�Ż������㷨ʱ��Ч�ʣ� "<<time2*1000<<endl;
}
int main()
{

    srand(time(0));
    int t[1000];
    int i,k;
    cout<<"��������";
    cin>>k;
    for(i=0; i<k; i++)
    {
        t[i] = rand()%1000;
        cout<<t[i]<<" ";
    }
    cout<<endl;
    cout<<"һ�������㷨:"<<endl;
    QuickSort(t,0,k);
    for(i=0; i<k; i++)
        cout<<t[i]<<" ";
    cout<<endl;
    cout<<"--------------------------------"<<endl;
    cout<<"��������";
    cin>>k;
    for(i=0; i<k; i++)
    {
        t[i] = rand()%1000;
        cout<<t[i]<<" ";
    }
    cout<<endl;
    cout<<"�Ż������㷨:"<<endl;
    QuickSort1(t,0,k);
    for(i=0; i<k; i++)
        cout<<t[i]<<" ";
    cout<<endl;
    cout<<"--------------------------------"<<endl;


   /*
    srand(time(0));
    int a1[100];
    int a2[100];
    int a3[100];
    int a4[10000];
    cout<<"-------------һ�����ݿ���ʱ�����ܱȽ�-------------"<<endl;
    create_array(a1,100,0);
    time_test(a1,100);
    cout<<endl;
    cout<<"-------------�������ݿ���ʱ�����ܱȽ�-------------"<<endl;
    create_array(a2,100,1);
    time_test(a2,100);
    cout<<endl;
    cout<<"-------------�������ݿ���ʱ�����ܱȽ�-------------"<<endl;
    create_array(a3,100,2);
    time_test(a3,100);
    cout<<endl;
    cout<<"-------------�����ݿ���ʱ�����ܱȽ�-------------"<<endl;
    create_array(a4,10000,0);
    time_test(a4,10000);
*/
    return 0;
}

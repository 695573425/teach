#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <time.h>
#include <queue>

using namespace std;

void CountingSort(int a[],int n,int MAX) //��������
{
    int i;
    int b[MAX],c[n];
    memset(b,0,MAX*sizeof(int));
    for(i=0; i<n; i++)
        b[a[i]]++;
    for(i=1; i<MAX; i++)
        b[i] += b[i-1];
    for(i=n-1; i>=0; i--)
        c[--b[a[i]]] = a[i];
    memcpy(a,c,n*sizeof(int));
}

int radix(int data, int p)
{
    int i,k;
    k=1;
    for(i=0;i<p-1;i++)
        k *=10;
    return (data%(k*10))/k;
}
void RadixSort(int figure, queue<int> &a)   //��������
{
    queue<int> q[10];
    int data,pass,r,i;
    for(pass=1; pass<=figure; pass++)
    {
        while(!a.empty())
        {
            data = a.front();
            a.pop();
            r = radix(data,pass);
            q[r].push(data);
        }
        for(i=0; i<=9; i++)
        {
            while(!q[i].empty())
            {
                data = q[i].front();
                q[i].pop();
                a.push(data);
            }
        }
    }

}

void InsertSort(int a[],int low,int high)     //��������
{
    int i,j;
    for(i=low+1; i<=high; i++)
    {
        j=i;
        while(j>low && a[j]<a[j-1])
        {
            swap(a[j],a[j-1]);j--;
        }
    }
}
void BucketSort(int a[],int n)           //Ͱ����
{
    int i,j,figure,MAX;
    int b[10][n+1];
    figure = MAX = 0;

    for(i=0;i<10;i++)
        b[i][0]=0;
    for(int i=0;i<n;i++)
        if(a[i]>MAX)
            MAX = a[i];
    while(MAX){
        figure++;MAX/=10;
    }

    for(i=0;i<n;i++)
    {
        j=++b[radix(a[i],figure)][0];
        b[radix(a[i],figure)][j] = a[i];
    }
    for(i=0;i<10;i++)
    {
        if(b[i][0]>1)
            InsertSort(b[i],1,b[i][0]);
    }

    int num=0;
    for(i=0;i<10;i++)
    {
        for(j=1;j<=b[i][0];j++)
            a[num++] = b[i][j];
    }
}


int main()
{
    int i,k;
    int a[30];
    queue<int> b;
    cout<<"---------------��������------------"<<endl;
    srand(time(0));
    for(i=0;i<30;i++)
    {
        a[i] = rand()%1000;
        cout<<a[i]<<" ";
    }
    cout<<endl;
    CountingSort(a,30,1000);
    cout<<"�����"<<endl;
    for(i=0;i<30;i++)
        cout<<a[i]<<" ";
    cout<<endl<<endl;
    cout<<"---------------��������------------"<<endl;
    for(i=0;i<30;i++)
    {
        b.push(rand()%1000);
        cout<<b.back()<<" ";
    }
    cout<<endl;
    RadixSort(3,b);
    cout<<"�����"<<endl;
    for(i=0;i<30;i++)
    {
        cout<<b.front()<<" ";
        b.pop();
    }
       cout<<endl<<endl;

    cout<<"---------------Ͱ����------------"<<endl;
    for(i=0;i<30;i++)
    {
        a[i] = rand()%1000;
        cout<<a[i]<<" ";
    }
    cout<<endl;
    BucketSort(a,30);
    cout<<"�����"<<endl;
    for(i=0;i<30;i++)
        cout<<a[i]<<" ";

    return 0;
}

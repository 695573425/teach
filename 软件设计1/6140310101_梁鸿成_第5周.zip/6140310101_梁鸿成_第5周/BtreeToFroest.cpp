#include <iostream>
#include <stdio.h>
using namespace std;

typedef struct node{
    char data;
    node *firstchild, *rightsib;
}*Tree,*Forest;

typedef struct node1{
    char data;
    node1 *lchild, *rchild;
}*BTree;

void CreatBTree(BTree &BT)
{

    char d;
    cin>>d;
    if(d=='#')
        BT=NULL;
    else
        {
            BT=new node1;
            BT->data=d;
            CreatBTree(BT->lchild);
            CreatBTree(BT->rchild);
        }
}

BTree Forest_To_Btree(Tree p)                              //ɭ��ת������
{
    BTree q;
    if(p == NULL)
        q = NULL;
    else
    {
        q = new node1;
        q->data = p->data;
        q->lchild = Forest_To_Btree(p->firstchild);
        q->rchild = Forest_To_Btree(p->rightsib);
    }
    return q;
}

Tree Btree_To_Forest(BTree p)                                    //������תɭ��
{
    Tree q;
    if(p == NULL)
        q = NULL;
    else
    {
        q = new node;
        q->data = p->data;
        q->firstchild = Btree_To_Forest(p->lchild);
        q->rightsib = Btree_To_Forest(p->rchild);
    }
    return q;
}
void BTout(BTree B)
{
    if(B)
    {
        cout<<B->data;
        BTout(B->lchild);
        BTout(B->rchild);
    }
}

void Fout(Forest F)
{
    node *p;
    if(F&&F->firstchild)
    {

        cout<<F->data<<":  ";

            p=F->firstchild;
            cout<<p->data<<"   ";
            while(p->rightsib)
            {
                p=p->rightsib;
                cout<<p->data<<"   ";
            }
            cout<<endl;
            p=F->firstchild;
            Fout(p);
            while(p->rightsib)
            {
                p=p->rightsib;
                Fout(p);
            }

        Fout(F->rightsib);
    }
}
int main()
{
  // ab#c#d##efg##h#i##jk###             //          a
    BTree BT,B;                          //      b        e
    Forest F;                            //       c    f    j
    cout<<"ǰ�����д�����������"<<endl;  //        d  g h  k
    CreatBTree(BT);                      //              i
    BTout(BT);
    cout<<endl;
    getchar();
    cout<<"������תɭ��"<<endl;
    getchar();
    F=Btree_To_Forest(BT);
    cout<<"����� ��  �ӽ��"<<endl; 
    Fout(F);
    getchar();
    cout<<"ɭ��ת������"<<endl;
    getchar();
    B=Forest_To_Btree(F);
    cout<<"������ǰ�����"<<endl;
    BTout(B);
    return 0;
}

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <fstream>
using namespace std;

#define max_size 100     //һƪӢ�����¿��ܺ��е������ĸ��������������

typedef struct{
    char data;
    int weight;
    int *child;
    int parent;
}HTNODE;
 typedef HTNODE *HuffmanT;          //��������

typedef struct{
    char ch;
    char *bits;
}CodeNode;
typedef CodeNode *HuffmanCode;         //�����������

int N;
int Total=0;;
HTNODE root;
void HuffmanT_Create(HuffmanT T, int n ,int k)
{
    int i,j,add,p1,p2,p3;
    HTNODE p;
    p.child = new int[k];
    p1 = 0;
    p2 = p3 = n-1;
    add = (n-1)%(k-1)+1;
    for(i=0;i<n;i++)
        for(j=n-1;j>i;j--)
            if(T[j].weight<T[j-1].weight)
            {
                p=T[j];  T[j]=T[j-1];  T[j-1]=p;
            }
    delete(p.child);

    if(add>=2)
    {
        T[++p3].child = new int[add];
        T[p3].weight = 0;
        T[p3].parent = -1;
        p2++;
        for(i=0;i<add;i++)
        {
            T[p3].weight += T[i].weight;
            T[p3].child[i] = p1;
            T[p1].parent = p3;
            p1++;
        }
    }

    while(p1<n || p2!=p3)
    {
        T[++p3].child = new int[k];
        T[p3].weight = 0;
        T[p3].parent = -1;
        for(i=0;i<k;i++)
        {
            if(p1<n)
                j = (T[p1].weight<=T[p2].weight)?p1++:p2++;
            else if(p2!=p3)
                j = p2++;
            T[p3].weight += T[j].weight;
            T[j].parent = p3;
            T[p3].child[i] = j;
        }
    }
     root=T[p3];
    return;
}

char* codetransf(char *s,int n)
{
    int k,i,j,m;
    char *p;
    char l[1];
    k = (int)ceil(log((double)n)/log(2));
    char t[k];
    int len=k*strlen(s);
    char *temp;
    temp =new char[2*len];
    strcpy(temp,"");
    for(i=0;i<strlen(s);i++)
    {
        l[0]=s[i];
        j=strtol(l,&p,n);
        itoa(j,t,2);
        for(m=0;m<k-strlen(t);m++)
            strcat(temp,"0");
        strcat(temp,t);
    }
    return temp;
}

HuffmanCode HuffmanEncoding(HuffmanT T, int n ,int k)          //����������������㷨
{
    HuffmanCode H = new CodeNode[n];
    int c,p,i,j;
    char temp[9];
    int start;
    char *s;
    temp[8] = '\0';        //��\0�ս�β
    for(i=0;i<n;i++)
    {
        H[i].ch = T[i].data;
        start = 8;
        c = i;
        while((p=T[c].parent)>=0)
        {
            j=0;
            while(T[p].child[j]!=c)
                j++;
            temp[--start] = ((j+48)<=57)?j+48:j+55;
            c = p;
        }
        s = new char[9-start];
        strcpy(s,&temp[start]);
        H[i].bits = codetransf(s,k);
    }
    return H;
}

HuffmanT T;
HuffmanCode HuffmanEncode(char* filename,int k)              //����һƪӢ������ filename ,���й���������ѹ������
{
    char alphabet[max_size];     //�������º��е���ĸ������
    char ch;
    int num[max_size];           //������ĸ�����ų��ֵ�Ƶ��
    int i,n;
    n = 0;
    ifstream in(filename);
    if(in.fail())
    {
        printf("Eorre open a file\n");
        return NULL;
    }
    for(i=0;i<max_size;i++)
        num[i]=0;

    in.seekg(0,ios::beg);
    while(in.get(ch))                //��ȡ�ַ���������������
    {
        Total++;
        if (strchr(alphabet,ch)==NULL)
        {
            alphabet[++n-1]=ch;
            num[n-1]++;
        }
        else
            num[strchr(alphabet,ch)-alphabet]++;
    }
    N=n;

    T = new HTNODE[n+((n-1)/(k-1))+1];
    for(i=0;i<n;i++)
    {
        T[i].data = alphabet[i];
        T[i].weight = num[i];
        T[i].parent = -1;
        T[i].child=NULL;
    }

    HuffmanT_Create(T,n,k);
    HuffmanCode H = HuffmanEncoding(T,n,k);                         //���������������

    for(i=0;i<n;i++)
        cout<<H[i].ch<<':'<<H[i].bits<<endl;

    in.close();
    return H;



}

void Comparess(char* filename,char* filename1,HuffmanCode H)               //ѹ��
{

    char ALPHAET[max_size];
    char ch;
    int i;
    unsigned char data=0;
    int bitcount=7;
    char *cur;
    i=0;
    for(i=0;i<N;i++)
        ALPHAET[i]=H[i].ch;
    ifstream f(filename);
    ofstream f1(filename1,ios::binary);
    if(f.fail())
    {
        printf("Eorre open a file\n");
        return;
    }
    f.seekg(0,ios::beg);
   // f1.seekp(0,ios::beg);
    while(f.get(ch))
    {

        cur=H[strchr(ALPHAET,ch)-ALPHAET].bits;
        while(*cur)
        {
            if(bitcount>=0)
            {
                data=data|((*cur-'0')<<bitcount);
                bitcount--;
            }
            if(bitcount<0)
            {
                f1.write((char*)&data,sizeof(char));
                bitcount=7;
                data=0;
            }
            cur++;
        }
    }
    f1.write((char*)&data,sizeof(char));
    f.close();
    f1.close();
    return;

}

void uncomparess(char* filename1, char* filename2,HuffmanCode H)                 //��ѹ
{
    int i,j;
    int start,rear;
    char temp[10];
    HTNODE cur;
    cur=root;
    unsigned char ch;
    i=0;
    ifstream f1(filename1,ios::binary);
    ofstream f2(filename2);
    if(f1.fail())
    {
        printf("Eorre open a file\n");
        return;
    }
  //  f1.seekg(0,ios::beg);
    f2.seekp(0,ios::beg);
    f1.read((char*)&ch,sizeof(char));
    while(Total)
    {
        unsigned int tmp;
        int bit=6;
        while(bit>=0)
        {
            for(tmp=0;i<20;i++)
            {
                if(ch&(tmp<<bit))
                {
                    cur=T[cur.child[tmp]];
                    bit -= 2;

                    break;
                }
            }
            if(cur.child==NULL)
            {

                f2<<cur.data;
                cur=root;
                Total--;
                if(!Total)
                    break;
            }
        }
        f1.read((char*)&ch,sizeof(char));
    }
    f1.close();
    f2.close();
}
/*
void Compress(char* filename,char* filename1,HuffmanCode H)
{
    char temp[max_size];
    char ch;
    int i;
    i=0;
    for(i=0;i<N;i++)
        temp[i]=H[i].ch;
    ifstream f(filename);
    ofstream f1(filename1);
    if(f.fail())
    {
        printf("Eorre open a file\n");
        return;
    }
    f.seekg(0,ios::beg);
    f1.seekp(0,ios::beg);
    while(f.get(ch))  //��ȡ�ַ���������������
        f1<<H[strchr(temp,ch)-temp].bits<<' ';
    f.close();
    f1.close();
    return;

}

void decoding(char* filename1, char* filename2,HuffmanCode H)
{
    int i,j;
    int start,rear;
    char temp[10];
    char ch;
    i=0;
    ifstream f1(filename1);
    ofstream f2(filename2);
    if(f1.fail())
    {
        printf("Eorre open a file\n");
        return;
    }
    f1.seekg(0,ios::beg);
    f2.seekp(0,ios::beg);
    while(f1.get(ch))
    {
        if(ch!=' '&&!f1.eof())
            temp[i++] = ch;
        else
        {
            temp[i]='\0';

            for(j=0; j<N; j++)
            {
                if(strcmp(temp,H[j].bits)==0)
                {

                    f2<<H[j].ch;
                    break;
                }
            }
            i=0;
        }
    }
    f1.close();
    f2.close();
}
*/
int main()
{


    char *filename = "test.txt";
    char *filename1 = "test1.bin";
    char *filename2 = "test2.txt";
    int k;
    cout<<"k���������ʵ��"<<endl<<"k:";
    cin>>k;
    HuffmanCode H = HuffmanEncode(filename,k);
    getchar();
    cout<<"����������"<<endl;
    getchar();
    Comparess(filename,filename1,H);

   // cout<<"����������"<<endl;
   // getchar();
   // uncomparess(filename1,filename2,H);

    return 0;
}

#include <iostream>
#include <string.h>
using namespace std;

typedef struct node{
    char data;
    node *father;
    node *lchild,*rchild;
    bool ltag,rtag;
}*PreTree,*PostTree;

node* CreateTree()
{
    node *temp;
    int i,n;
    char s[100];
    cin>>s+1;
    n = strlen(s);
    node **p;
    p = new node*[2*n];
    p[0]=NULL;
    for(i=1;i<2*n;i++)
    {
        if(s[i]=='#'||i>n-1)
            p[i]=NULL;
        else
        {
            p[i] = new node;
            p[i]->data = s[i];
        }
    }
    for(i=1;i<n;i++)
    {
        if(p[i])
        {
            p[i]->lchild = p[2*i];
            p[i]->rchild = p[2*i+1];
            p[i]->father = p[i/2];
        }

    }
    temp = p[1];
    delete p ;

    return temp;
}


node *pre=NULL;
void PreOrderTh(PreTree p)            //ǰ������������������
{
    if(p){
        p->ltag = (p->lchild)?true:false;
        p->rtag = (p->rchild)?true:false;
        if(pre){
            if(pre->rtag == false)
                pre->rchild = p;
            if(p->ltag == false)
                p->lchild = pre;
        }
        pre = p;
        if(p->ltag==true)
            PreOrderTh(p->lchild);
        if(p->rtag==true)
            PreOrderTh(p->rchild);
    }
    return;
}

PreTree PreNext(PreTree p)           //����ǰ���������������p��̽��
{
    if(p->ltag==true)
        return p->lchild;
    else
        return p->rchild;
}

void ThPreOrder(PreTree head)        //ǰ����������������
{
    PreTree tmp;
    tmp = head;
    do{
        cout<<tmp->data<<' ';
        tmp = PreNext(tmp);
    }while(tmp!=NULL);
    cout<<endl;
}



void PostOrderTh(PostTree p)          //��������������������
{
    if(p!=NULL){
        p->ltag = (p->lchild)?true:false;
        p->rtag = (p->rchild)?true:false;
        if(p->lchild)
            PostOrderTh(p->lchild);
        if(p->rchild)
            PostOrderTh(p->rchild);
        if(pre){
            if(pre->rtag == false)
                pre->rchild = p;
            if(p->ltag == false)
                p->lchild = pre;
        }
        pre = p;
    }

}

PostTree PostNext(PostTree p)         //���غ����������������p��̽��
{
    node *temp;
    if(p->rtag==true)
    {
        if(p->father->lchild == p)
        {
            temp = p->father;
            if(!temp->rtag)
                return temp;
            temp = temp->rchild;
            while(temp->ltag||temp->rtag)
            {
                if(temp->ltag)
                    temp = temp->lchild;
                else
                    temp = temp->rchild;
            }
            return temp;
        }
        else
            return p->father;
    }
    else
        return p->rchild;
}

void ThPostOrder(PostTree head,node *root)       //������������������
{
    PostTree tmp;
    tmp = head;
    do{
        tmp = PostNext(tmp);
        cout<<tmp->data<<' ';
    }while(tmp!=root);
    cout<<endl;
}


int main()
{



    node* root ;
    PreTree PreHead = new node;
    PostTree PostHead = new node;
    cout<<"������˳�򴴽���������"<<endl;  //abdh##i##ej###cf##g##
    root = CreateTree();

    PreHead->ltag=true;
    PreOrderTh(root);

    cout<<"ǰ����������"<<endl;
    ThPreOrder(root);

    cout<<"������˳�򴴽���������"<<endl;
    root = CreateTree();
    pre = PostHead;
    pre->rtag=false;
    pre->ltag=true;

    PostOrderTh(root);
    pre->father = PostHead;
    cout<<"������������"<<endl;
    ThPostOrder(PostHead,root);



    return 0;
}

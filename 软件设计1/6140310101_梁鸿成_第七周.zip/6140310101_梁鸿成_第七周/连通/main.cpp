#include<stdio.h>
#include <iostream>
#include <stack>
#include<algorithm>
#define max_size 100
using namespace std;


typedef struct node{
    int adjvex;
    int cost;
    node* next;
}EdgeNode;

typedef struct{
    int data;
    node* firstedge;
}VertexNode;

typedef struct {
    VertexNode vexlist[max_size];
    int n,e;
}AdjGraph;

EdgeNode* makeedge(int i)
{
    EdgeNode *p;
    p = new node;
    p->adjvex = i;
    p->next = NULL;
    return p;
}
stack<int> S;
int instack[max_size];

class Tarjan
{
    public:
    Tarjan(AdjGraph T):G(T),index(0)
    {
        int i;
        for(i=0;i<max_size;i++)
            instack[i] = dfn[i]=low[i]=0;
        while(!S.empty())
            S.pop();
    }
    ~Tarjan(){};
    void DFSArticul(int u)
    {
        int MIN,v;
        node* p ;
        dfn[u] = MIN = ++index;
        for(p=G.vexlist[u].firstedge; p; p=p->next)
        {
            v = p->adjvex;
            if(dfn[v] == 0)
            {
                DFSArticul(v);
                if(low[v] < MIN)
                   MIN = low[v];
                if(low[v] >= dfn[u])
                    cout<<G.vexlist[u].data<<"   ";
            }
            else if(dfn[v]< MIN)
               MIN = dfn[v];
        }
        low[u]= MIN;
    }

    void FindArticul()
    {
        int i,u;
        node *p;
        index =1; dfn[0] = 1;
        for(i=1;i<G.n;i++)
            dfn[i] = 0;
        p = G.vexlist[0].firstedge;
        u = p->adjvex;
        DFSArticul(u);
        if(index<G.n)
        {
            cout<<G.vexlist[0].data<<"   ";
            while(p=p->next)
            {
                u = p->adjvex;
                if(dfn[u] == 0)
                    DFSArticul(u);
            }
        }

    }

    void tarjan(int u)
    {
        int v;
        node *p;
        dfn[u] = low[u] = ++index;
        instack[u] = 1;
        S.push(u);
        for(p=G.vexlist[u].firstedge; p; p=p->next)
        {
            v = p->adjvex;
            if(dfn[v]==0)
            {
                tarjan(v);
                low[u] = min(low[u],low[v]);
            }
            else
                if(instack[v]==1)
                    low[u] = min(low[u],dfn[v]);
        }
        if(dfn[u]==low[u])
        {
            do{
                v = S.top();
                cout<<S.top()<<"   ";
                S.pop();
                instack[v] = 0;
            }while(u!=v);
            cout<<endl;
        }
    }

    private:
    AdjGraph G;
    int dfn[max_size];
    int low[max_size];
    int index;
};

AdjGraph undirected_graph_test()
{
    EdgeNode *p;
    AdjGraph G;
    G.n = 9;
    G.e = 20;
    int i;
    for(i=0; i<9;i++)
        G.vexlist[i].data = i;
    p = G.vexlist[0].firstedge = makeedge(1);
    p = p->next = makeedge(2);
    p = p->next = makeedge(3);
    p = p->next = NULL;
    p = G.vexlist[1].firstedge = makeedge(0);
    p = p->next = makeedge(2);
    p = p->next = makeedge(4);
    p = p->next = NULL;
    p = G.vexlist[2].firstedge = makeedge(0);
    p = p->next = makeedge(1);
    p = p->next = makeedge(5);
    p = p->next = NULL;
    p = G.vexlist[3].firstedge = makeedge(0);
    p = p->next = makeedge(5);
    p = p->next = NULL;
    p = G.vexlist[4].firstedge = makeedge(1);
    p = p->next = makeedge(6);
    p = p->next = NULL;
    p = G.vexlist[5].firstedge = makeedge(7);
    p = p->next = makeedge(3);
    p = p->next = makeedge(2);
    p = p->next = NULL;
    p = G.vexlist[6].firstedge = makeedge(4);
    p = p->next = NULL;
    p = G.vexlist[7].firstedge = makeedge(8);
    p = p->next = makeedge(5);
    p = p->next = NULL;
    p = G.vexlist[8].firstedge = makeedge(7);
    p = p->next = NULL;
    return G;

}

AdjGraph oriented_graph_test()
{
    EdgeNode *p;
    AdjGraph G;
    G.n = 6;
    G.e = 8;
    int i;
    for(i=0; i<9;i++)
        G.vexlist[i].data = i;
    p = G.vexlist[0].firstedge = makeedge(1);
    p = p->next = makeedge(3);
    p = p->next = NULL;
    p = G.vexlist[1].firstedge = makeedge(2);
    p = p->next = makeedge(4);
    p = p->next = NULL;
    p = G.vexlist[2].firstedge = makeedge(5);
    p = p->next = NULL;
    p = G.vexlist[3].firstedge = makeedge(4);
    p = p->next = NULL;
    p = G.vexlist[4].firstedge = makeedge(0);
    p = p->next = makeedge(0);
    p = p->next = NULL;
    p = G.vexlist[5].firstedge = NULL;
    return G;
}
int main()
{


    cout<<"����ͼ˫��ͨ�Բ��ԣ������㣺"<<endl;
    getchar();
    Tarjan test1 =  Tarjan(undirected_graph_test());
    test1.FindArticul();
    cout<<endl;
    getchar();
    cout<<"����ͼǿ��ͨ�Բ��ԣ����ǿ��ͨ������"<<endl;
    getchar();
    Tarjan test2 = Tarjan(oriented_graph_test());
    test2.tarjan(0);

    return 0;
}

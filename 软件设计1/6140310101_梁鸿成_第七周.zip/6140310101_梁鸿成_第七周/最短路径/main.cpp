#include <iostream>
#include <limits.h>
#include <stdio.h>
#include <vector>
#define max_size 100
using namespace std;

struct Edge{
    int bgn,End,weight;
};

class Dijkstra
{
    public:
    Dijkstra():n(0)
    {
        int i,j;
        for(i=0; i<max_size; i++)
            for(j=0; j<max_size; j++)
            {
                if(i==j)
                    G[i][j] = 0;
                else
                    G[i][j] = INT_MAX;
            }
    }
    ~Dijkstra(){};

    void addedges(int bgn, int End, int weight)
    {
        if(bgn==End)
            return;
        else if(bgn>=n || End>=n)
            n++;
        G[bgn][End] = weight;
    }

    int mincost()
    {
        int i,j;
        int temp = INT_MAX;
        j=1;
        for(i=1; i<n; i++)
            if(S[i]==0 && lowcost[i]<temp)
            {
                temp = lowcost[i];
                j=i;
            }
        return j;
    }

    void dijkstra()
    {
        int i,j,k,sum;
        for(i=1; i<n; i++)
        {
            lowcost[i] = G[0][i];
            S[i] = closest[i] = 0;
        }
        S[0] = 1;
        for(i=0; i<n-1; i++)
        {
            j = mincost();
            S[j] = 1;
            for(k=1; k<n; k++)
                if(S[k] == 0)
                {
                    if(G[j][k]!=INT_MAX)
                    {
                        sum = lowcost[j] + G[j][k];
                        if(sum < lowcost[k])
                        {
                            lowcost[k] = sum;
                            closest[k] = j;
                        }
                    }

                }
        }

    }

    void Floyd()
    {
        int i,j,k;
        int A[n][n];
        int P[n][n];
        for(i=0; i<n; i++)
            for(j=0; j<n; j++)
            {
                A[i][j] = G[i][j];
                P[i][j] = -1;
            }
        for(k=0; k<n; k++)
            for(i=0; i<n; i++)
                for(j=0; j<n; j++)
                {
                    if(A[i][k]<INT_MAX && A[k][j]<INT_MAX && A[i][k]+A[k][j]<A[i][j])
                    {
                        A[i][j] = A[i][k] + A[k][j];
                        P[i][j] = k;
                    }
                }
        for(i=0; i<n; i++)
            for(j=0; j<n; j++)
            {
                if(A[i][j] > 0)
                    cout<<i<<","<<j<<"   "<<A[i][j]<<endl;
            }
    }
    void test()
    {
        int i,j;
        n=5;
        addedges(0,1,10);
        addedges(0,3,30);
        addedges(0,4,100);
        addedges(1,2,50);
        addedges(2,3,20);
        addedges(2,4,10);
        addedges(3,2,20);
        addedges(3,4,60);
        cout<<"ͼ�ڽӾ���"<<endl;
        for(i=0; i<n; i++)
        {
            for(j=0; j<n; j++)
            {
                if(G[i][j] ==INT_MAX)
                    cout<<'#'<<"  ";
                else
                    cout<<G[i][j]<<"  ";
            }
            cout<<endl;
        }
        dijkstra();
        getchar();
        for(i=1; i<n; i++)
        {

            cout<<closest[i]<<","<<i<<"   "<<G[closest[i]][i]<<endl;
        }
    }

    void test1()
    {
        int i,j;
        n=4;
        addedges(0,1,1);
        addedges(0,3,4);
        addedges(1,2,9);
        addedges(1,3,2);
        addedges(2,0,3);
        addedges(2,1,5);
        addedges(2,3,8);
        addedges(3,2,6);
        cout<<"ͼ�ڽӾ���"<<endl;
        for(i=0; i<n; i++)
        {
            for(j=0; j<n; j++)
            {
                if(G[i][j] ==INT_MAX)
                    cout<<'#'<<"  ";
                else
                    cout<<G[i][j]<<"  ";
            }
            cout<<endl;
        }
        getchar();
        Floyd();
    }
    private:
    int n;
    int G[max_size][max_size];
    int lowcost[max_size];
    int closest[max_size];
    int S[max_size];


};



int main()
{
  /*  cout<<"Dijkstra�㷨���ԣ�"<<endl;
    getchar();
    Dijkstra G = Dijkstra();
    G.test();
    G.~Dijkstra();
    cout<<endl;*/
    cout<<"Floyd�㷨���ԣ�"<<endl;
    getchar();
    Dijkstra C = Dijkstra();
    C.test1();
    C.~Dijkstra();
    return 0;
}

#include <iostream>
#include <limits.h>
#include <stdio.h>
#define max_size 100
using namespace std;

struct Edge{
    int bgn,End,weight;
};

class Prim
{
    public:
    Prim():n(0)
    {
        int i,j;
        for(i=0; i<max_size; i++)
            for(j=0; j<max_size; j++)
            {
                if(i==j)
                    G[i][j] = 0;
                else
                    G[i][j] = INT_MAX-1;
            }
    }
    ~Prim(){};

    void addedges(int bgn, int End, int weight)
    {
        if(bgn>=n || End>=n)
            n++;
        G[bgn][End] = G[End][bgn] = weight;
    }

    void prim()
    {
        int i,j,k,Min;
        for(i=1; i<n; i++)
        {
            lowcost[i] = G[0][i];
            closest[i] = 0;
        }
        for(i=1; i<n; i++)
        {
            Min = lowcost[i];
            for(j=1; j<n; j++)
                if(lowcost[j]<Min)
                {
                    Min = lowcost[j];
                    k=j;
                }
            lowcost[k] = INT_MAX;
            for(j=1; j<n; j++)
                if(G[k][j]<lowcost[j] && lowcost[j]<INT_MAX)
                {
                    lowcost[j] = G[k][j];
                    closest[j] = k;
                }
        }
    }

    void test()
    {
        int i,j;
        n=6;
        addedges(0,1,3);
        addedges(0,2,1);
        addedges(0,3,6);
        addedges(0,4,6);
        addedges(1,2,7);
        addedges(1,3,5);
        addedges(2,3,6);
        addedges(2,4,7);
        addedges(2,5,8);
        addedges(4,5,4);
        cout<<"ͼ�ڽӾ���"<<endl;
        for(i=0; i<n; i++)
        {
            for(j=0; j<n; j++)
            {
                if(G[i][j] ==INT_MAX-1)
                    cout<<'#'<<"  ";
                else
                    cout<<G[i][j]<<"  ";
            }
            cout<<endl;
        }
        prim();
        getchar();
        for(i=1; i<n; i++)
        {

            cout<<i<<","<<closest[i]<<"   "<<G[i][closest[i]]<<endl;
        }
    }
    private:
    int n;
    int G[max_size][max_size];
    int lowcost[max_size];
    int closest[max_size];

};

class Kruskal
{
    public:
    Kruskal():e(0)
    {
        int i;
        for(i=0; i<max_size; i++)
        {
            label[i] = -1;
            father[i]= -1;
        }
    }
    ~Kruskal(){};

    void makeedge(int bgn, int End, int weight)
    {
        Edge p;
        p.bgn = bgn;
        p.End = End;
        p.weight = weight;
        edges[e++]= p;
    }

    int Find(int i)
    {
        int j=i;
        while(father[j]>=0)
            j=father[j];
        return j;
    }

    void Sort()
    {
        Edge temp;
        for(int i=0; i<e-1; i++)
        {
            for(int j=0; j<e-1; j++)
            {
                if(edges[j].weight>edges[j+1].weight)
                {
                    temp = edges[j];
                    edges[j] = edges[j+1];
                    edges[j+1] = temp;
                }
            }
        }

    }

    void kruskal()
    {
        int bnf,edf,i;
        for(i=0; i<e; i++)
        {
            bnf = Find(edges[i].bgn);
            edf = Find(edges[i].End);
            if(bnf!=edf)
            {
                father[bnf] = edf;
                label[i]++;
            }
        }
    }

    void test()
    {
        int i;
        makeedge(0,1,2);
        makeedge(0,2,3);
        makeedge(1,3,2);
        makeedge(2,3,1);
        makeedge(3,4,2);
        makeedge(3,5,4);
        makeedge(4,5,1);
        makeedge(4,6,2);
        makeedge(5,6,2);
        makeedge(5,7,1);
        makeedge(6,7,3);
        Sort();
        cout<<"ͼ���ߵ�ͷ��β��Ȩֵ��"<<endl;
        for(i=0; i<e; i++)
            cout<<edges[i].bgn<<" "<<edges[i].End<<" "<<edges[i].weight<<endl;
        kruskal();
        cout<<"Kruskal�㷨����С��������"<<endl;
        for(i=0; i<e; i++)
        {
            if(label[i]>=0)
                cout<<edges[i].bgn<<","<<edges[i].End<<"   "<<edges[i].weight<<endl;
        }
    }

    private:
    Edge edges[max_size];
    int label[max_size];
    int father[max_size];
    int e;
};

int main()
{
    cout<<"Prim�㷨���ԣ�"<<endl;
    getchar();
    Prim G = Prim();
    G.test();
    G.~Prim();
    cout<<endl;
    cout<<"Kruskal�㷨���ԣ�"<<endl;
    getchar();
    Kruskal K = Kruskal();
    K.test();
    K.~Kruskal();

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max_size 1000
typedef struct string{
    char *s;
    int size;
}str;

str create_string(int i)
{
    char*s1;
    str S;
    s1 = malloc(max_size);
    if(i==0)
        printf("������������\n");
    else
        printf("������ģʽ����\n");
    gets(s1);
    S.size = strlen(s1);
    S.s = malloc(S.size);
    strcpy(S.s,s1);
    free(s1);
    return S;
}


void get_next(str T,int next[])
{
    int i,j;
    i=0;
    j=-1;
    next[0]=-1;
    while(i<T.size-1)
    {
        if(j==-1||T.s[i]==T.s[j])
            next[++i] = ++j;
        else
            j = next[j];
    }
}
void print(int i,int j,str S,str T)
{
    int k;
    printf("%s\n",S.s);
    for(k=0;k<i-j;k++)
        printf(" ");
    for(k=0;k<=j;k++)
        printf("%c",T.s[k]);
    printf("\n");
}

void KMP(str S,str T,int next[])
{
    int i,j,count;
    i=j=count=0;
    while(i<S.size&&j<T.size)
    {
        if(S.s[i]==T.s[j])
        {
            i++;j++;
            if(j==T.size)
            {
                count++;
                print(i,j,S,T);
                printf("ƥ��������%d\n",count);
            }
        }
        else if(S.s[i]!=T.s[j]&&j==0)
        {
            count++;
            print(i,j,S,T);
            i++;
        }
        else
        {
            count++;
            print(i,j,S,T);
            j=next[j];
        }
    }
    if(j>=T.size)
        printf("ƥ��ɹ���������%d��Ԫ��\n",i-T.size+1);
    else
        printf("ƥ��ʧ��\n");
}
int main()
{
    str S,T;
    int i;
    S = create_string(0);  //acabaabaabcacaabc
    T = create_string(1);  //abaabc
    int next[T.size];
    get_next(T,next);
    KMP(S,T,next);
    return 0;
}
